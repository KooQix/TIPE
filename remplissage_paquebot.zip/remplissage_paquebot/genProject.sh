#! /bin/bash

cd src
make
rm moc_* *.o
cd ..
