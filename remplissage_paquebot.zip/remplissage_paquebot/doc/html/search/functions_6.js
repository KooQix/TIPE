var searchData=
[
  ['triinsert_26',['triInsert',['../classWindow.html#a86c9a8a0adc88b56088d7b9752ea0277',1,'Window']]]
];
